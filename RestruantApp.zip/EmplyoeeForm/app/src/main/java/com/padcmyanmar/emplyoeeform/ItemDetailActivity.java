package com.padcmyanmar.emplyoeeform;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.padcmyanmar.emplyoeeform.adapters.ItemDetailImageAdapter;

public class ItemDetailActivity extends AppCompatActivity {
    public static Intent newIntent(Context context)
    {
        Intent intent=new Intent(context,ItemDetailActivity.class);
        return intent;
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_item_detial);

        ViewPager vp_pager=findViewById(R.id.vp_item_image);
        ItemDetailImageAdapter item_image_adapter=new ItemDetailImageAdapter();
        vp_pager.setAdapter(item_image_adapter);
    }

}
