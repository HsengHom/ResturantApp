package com.padcmyanmar.emplyoeeform.delegates;

public interface FoodItemDelegate {
    void onTapFoodItem();
}
