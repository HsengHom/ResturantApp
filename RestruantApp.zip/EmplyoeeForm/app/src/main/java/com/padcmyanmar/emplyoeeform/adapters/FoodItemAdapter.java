package com.padcmyanmar.emplyoeeform.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.padcmyanmar.emplyoeeform.R;
import com.padcmyanmar.emplyoeeform.delegates.FoodItemDelegate;
import com.padcmyanmar.emplyoeeform.views.holder.FoodItemViewHolder;

import java.util.zip.Inflater;

public class FoodItemAdapter extends RecyclerView.Adapter<FoodItemViewHolder>{
    private FoodItemDelegate mDelegate;

  public   FoodItemAdapter(FoodItemDelegate foodItemDelegate)
  {
      mDelegate=foodItemDelegate;
  }
    @NonNull
    @Override
    public FoodItemViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater layoutInflater=LayoutInflater.from(viewGroup.getContext());
        View viewItem=layoutInflater.inflate(R.layout.food_item,viewGroup,false);

        return new FoodItemViewHolder(viewItem,mDelegate);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodItemViewHolder foodItemViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
