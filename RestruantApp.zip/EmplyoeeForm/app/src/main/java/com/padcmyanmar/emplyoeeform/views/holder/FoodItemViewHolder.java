package com.padcmyanmar.emplyoeeform.views.holder;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;

import com.padcmyanmar.emplyoeeform.delegates.FoodItemDelegate;

public class FoodItemViewHolder extends ViewHolder {
      private FoodItemDelegate mDelegate;;


    public FoodItemViewHolder(@NonNull View itemView, @NonNull FoodItemDelegate foodItemDelegate)
    {
        super(itemView);
        mDelegate=foodItemDelegate;
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDelegate.onTapFoodItem();
            }
        });

    }
}
